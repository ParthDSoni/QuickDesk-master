﻿// Norwegian translation by Vegard S.
CKEDITOR.plugins.setLang('wordcount', 'no', {
    WordCount: 'Ord:',
    CharCount: 'Tegn:',
    CharCountWithHTML: 'Tegn (including HTML):',
    Paragraphs: 'Paragraphs:',
    ParagraphsRemaining: 'Paragraphs remaining',
    pasteWarning: 'Content can not be pasted because it is above the allowed limit',
    Selected: 'Selected: ',
    title: 'Statistikk'
});
